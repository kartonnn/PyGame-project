import pygame
import random
import time

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)


class Mathgame:
    def __init__(self):
        pygame.init()

        self.screen_width = 300
        self.screen_height = 300
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        self.font = pygame.font.Font(None, 52)


    def run(self):
        running = True
        score = 0
        answer = ''
        start_time = time.time()
        game_duration = 30
        question, correct_answer = self.generate_question()

        while running:
            self.screen.fill(BLACK)
            time_left = game_duration - (time.time() - start_time)
            if time_left <= 0:
                score_surf_end = self.font.render(f'счёт: {score}', True, WHITE)
                if score < 10:
                    result_end = self.font.render(f'ваш счёт слишком маленький', True, WHITE)
                else:
                    result_end = self.font.render(f'вы прошли', True, WHITE)
                self.screen.blit(result_end, (self.screen_width // 2 - 100, self.screen_height // 2 - 400))
                self.screen.blit(score_surf_end, (self.screen_width // 2 - 100, self.screen_height // 2 - 100))
                pygame.display.update()
                time.sleep(3)
                running = False
                continue

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        if answer == str(correct_answer):
                            score += 1
                            question, correct_answer = self.generate_question()
                        answer = ''
                    elif event.key == pygame.K_BACKSPACE:
                        answer = answer[:-1]
                    else:
                        answer += event.unicode
            question_surf = self.font.render(question, True, WHITE)
            self.screen.blit(question_surf, (50, 50))
            answer_surf = self.font.render(answer, True, WHITE)
            self.screen.blit(answer_surf, (50, 100))
            score_surf = self.font.render(f'Счет: {score}', True, WHITE)
            self.screen.blit(score_surf, (50, 150))
            time_surf = self.font.render(f'Время: {int(time_left)}', True, WHITE)
            self.screen.blit(time_surf, (50, 200))

            pygame.display.flip()

        pygame.quit()

    def generate_question(self):
        num1 = random.randint(1, 10)
        num2 = random.randint(1, 10)
        return f"{num1} x {num2}", num1 * num2


Mathgame().run()